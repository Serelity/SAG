import unittest

from ragflow_style_pipeline.sag_entity_llm import (
    build_extraction_prompt,
    candidate_to_link,
    extract_links_from_llm_response,
    parse_llm_json,
)


class TestSagEntityLlm(unittest.TestCase):
    def test_prompt_limits_entity_types_to_sag_retrieval_schema(self):
        order = {
            "doc_id": "order_a",
            "title_clean": "流动摊贩占道",
            "case_content_clean": "市民反映广成路有流动摊贩占道经营。",
            "case_goal_clean": "希望处理",
            "address_detail_clean": "",
        }
        prompt = build_extraction_prompt(order, {"max_text_chars": 1000})

        self.assertIn("problem_object", prompt)
        self.assertIn("problem_behavior", prompt)
        self.assertIn("intersection", prompt)
        self.assertIn("不要输出满意度", prompt)
        self.assertIn("只输出 JSON", prompt)

    def test_parse_llm_json_extracts_first_json_object(self):
        parsed = parse_llm_json(
            '```json\n{"entities":[{"entity_type":"road","entity_value":"广成路","source_field":"case_content_clean","evidence_span":"广成路","confidence":0.9}]}\n```'
        )

        self.assertEqual(parsed["entities"][0]["entity_value"], "广成路")

    def test_extract_links_rejects_missing_evidence_and_generic_noise(self):
        order = {
            "doc_id": "order_a",
            "case_content_clean": "市民反映广成路有流动摊贩占道经营。",
            "case_goal_clean": "",
            "title_clean": "",
            "address_detail_clean": "",
        }
        response = """
        {
          "entities": [
            {"entity_type":"road","entity_value":"广成路","source_field":"case_content_clean","evidence_span":"广成路","confidence":0.91},
            {"entity_type":"road","entity_value":"道路","source_field":"case_content_clean","evidence_span":"道路","confidence":0.91},
            {"entity_type":"poi","entity_value":"不存在市场","source_field":"case_content_clean","evidence_span":"不存在市场","confidence":0.91}
          ]
        }
        """

        links, rejects = extract_links_from_llm_response(order, response, {"min_confidence": 0.55})

        self.assertEqual([(link.entity_type, link.entity_value) for link in links], [("road", "广成路")])
        self.assertEqual([reject["reason"] for reject in rejects], ["generic_entity_value", "missing_evidence_span"])

    def test_candidate_to_link_uses_llm_source_channel(self):
        link = candidate_to_link(
            "order_a",
            {
                "entity_type": "problem_behavior",
                "entity_value": "挡住人行道",
                "source_field": "case_content_clean",
                "evidence_span": "挡住人行道",
                "confidence": 0.8,
            },
        )

        self.assertEqual(link.entity_type, "problem_behavior")
        self.assertEqual(link.entity_value, "占道经营")
        self.assertEqual(link.source_channel, "llm")


if __name__ == "__main__":
    unittest.main()
